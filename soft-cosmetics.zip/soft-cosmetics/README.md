# Soft Cosmetics
Fabric 1.21.11 cosmetics mod. First item: Frozen Horns of the Frigid Planes (light blue fire).

Get it from the "Soft Cosmetics" creative tab, then right-click to wear it on your head.
Tweak size/position in `HornMesh.java` (`SCALE`, `BASE_UP`). Fire color is `FIRE_COLOR` in `SoftCosmeticsClient.java`.

Build: push to GitHub, run the "build" workflow, download the jar from the run's Artifacts.
