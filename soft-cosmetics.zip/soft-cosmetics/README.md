# Soft Cosmetics
Fabric 1.21.11 cosmetics mod. First item: Frozen Horns of the Frigid Planes (light blue fire).

Get it from the "Soft Cosmetics" creative tab, then right-click to wear it on your head.
Tweak horn size/position in `HornMesh.java` (`SCALE`, `BASE_UP`) and the flame in `HornsFeatureRenderer.java` (`FLAME_WIDTH`, `FLAME_HEIGHT`).

Build: push to GitHub, run the "build" workflow, download the jar from the run's Artifacts.
