package com.softcosmetics;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class SoftCosmetics implements ModInitializer {
	public static final String MOD_ID = "softcosmetics";
	public static Item FROZEN_HORNS;

	@Override
	public void onInitialize() {
		Identifier id = Identifier.of(MOD_ID, "frozen_horns");
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
		// equippable(HEAD) lets you right-click to wear it. No armor model is set,
		// because we draw the horns ourselves in HornsFeatureRenderer.
		FROZEN_HORNS = Registry.register(Registries.ITEM, id,
			new Item(new Item.Settings().registryKey(key).maxCount(1).rarity(Rarity.RARE)
				.equippable(EquipmentSlot.HEAD)));

		RegistryKey<ItemGroup> groupKey = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(MOD_ID, "cosmetics"));
		Registry.register(Registries.ITEM_GROUP, groupKey, FabricItemGroup.builder()
			.icon(() -> new ItemStack(FROZEN_HORNS))
			.displayName(Text.literal("Soft Cosmetics"))
			.entries((ctx, entries) -> entries.add(FROZEN_HORNS))
			.build());
	}
}
