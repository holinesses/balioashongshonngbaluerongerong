package com.softcosmetics.client;

import com.softcosmetics.SoftCosmetics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;

public class HornsFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	private static final Identifier HORNS = Identifier.of(SoftCosmetics.MOD_ID, "textures/entity/frozen_horns.png");
	private static final Identifier FLAME = Identifier.of(SoftCosmetics.MOD_ID, "textures/entity/frozen_flame.png");
	private static final Identifier GLOW = Identifier.of(SoftCosmetics.MOD_ID, "textures/entity/frozen_glow.png");

	/** Where the fire starts above the neck pivot (head top = 0.5). */
	private static final float FLAME_BASE_UP = 0.40f;
	/** Overall fire size multiplier. 1.0 = default, 1.3 = 30% bigger. */
	private static final float FIRE_SIZE = 1.0f;
	private static final int FULL_BRIGHT = 0xF000F0;

	// each tongue: x offset, z offset, width, height, phase, plane rotation (degrees)
	private static final float[][] TONGUES = {
		{ 0.00f,  0.00f, 0.80f, 1.20f, 0.0f,  0f },   // big main flame
		{-0.16f,  0.04f, 0.50f, 0.85f, 1.7f, 20f },
		{ 0.16f, -0.04f, 0.50f, 0.90f, 3.1f, 40f },
		{ 0.03f,  0.14f, 0.45f, 0.75f, 4.6f, 10f },
		{-0.04f, -0.14f, 0.45f, 0.80f, 5.9f, 50f },
	};

	public HornsFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
					   PlayerEntityRenderState state, float limbAngle, float limbDistance) {
		if (state.invisible) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null) return;
		Entity e = mc.world.getEntityById(state.id);
		if (!(e instanceof PlayerEntity p) || !p.getEquippedStack(EquipmentSlot.HEAD).isOf(SoftCosmetics.FROZEN_HORNS)) return;

		final float age = state.age;

		matrices.push();
		getContextModel().head.applyTransform(matrices); // follow the head's position, rotation and sneaking

		queue.submitCustom(matrices, RenderLayers.entityCutoutNoCull(HORNS),
			(entry, consumer) -> HornMesh.draw(entry, consumer, light));

		// soft blue glow behind the fire
		queue.submitCustom(matrices, RenderLayers.eyes(GLOW), (entry, vc) -> {
			float pulse = 1f + 0.08f * (float) Math.sin(age * 0.5f);
			float s = 1.5f * FIRE_SIZE * pulse;
			planes(entry, vc, 0f, 0f, s, s, FLAME_BASE_UP + 0.1f * FIRE_SIZE, 0f, 0f, 3);
		});

		// the fire: one big flame plus several tongues flickering out of sync
		queue.submitCustom(matrices, RenderLayers.eyes(FLAME), (entry, vc) -> {
			for (float[] t : TONGUES) {
				float ph = t[4];
				float flick = 1f + 0.13f * (float) Math.sin(age * 0.9f + ph) + 0.07f * (float) Math.sin(age * 2.3f + ph * 2f);
				float wob = 1f + 0.06f * (float) Math.sin(age * 1.4f + ph);
				float sway = 0.07f * (float) Math.sin(age * 0.55f + ph);
				planes(entry, vc, t[0] * FIRE_SIZE, t[1] * FIRE_SIZE,
					t[2] * wob * FIRE_SIZE, t[3] * flick * FIRE_SIZE,
					FLAME_BASE_UP, sway, t[5], 3);
			}
		});

		matrices.pop();
	}

	/** A sprite drawn as several crossed vertical planes, so it looks full from every side. */
	private static void planes(MatrixStack.Entry e, VertexConsumer vc, float ox, float oz, float w, float h,
							   float baseUp, float sway, float rotDeg, int count) {
		float yB = -baseUp;          // model space is Y-down
		float yT = -(baseUp + h);
		for (int i = 0; i < count; i++) {
			double a = Math.toRadians(rotDeg + i * (180.0 / count));
			float dx = (float) Math.cos(a) * w / 2f;
			float dz = (float) Math.sin(a) * w / 2f;
			float sx = (float) Math.cos(a) * sway;
			float sz = (float) Math.sin(a) * sway;
			// front face, then back face (so it shows whichever way culling goes)
			v(e, vc, ox - dx, yB, oz - dz, 0, 1);
			v(e, vc, ox + dx, yB, oz + dz, 1, 1);
			v(e, vc, ox + dx + sx, yT, oz + dz + sz, 1, 0);
			v(e, vc, ox - dx + sx, yT, oz - dz + sz, 0, 0);

			v(e, vc, ox - dx + sx, yT, oz - dz + sz, 0, 0);
			v(e, vc, ox + dx + sx, yT, oz + dz + sz, 1, 0);
			v(e, vc, ox + dx, yB, oz + dz, 1, 1);
			v(e, vc, ox - dx, yB, oz - dz, 0, 1);
		}
	}

	private static void v(MatrixStack.Entry e, VertexConsumer vc, float x, float y, float z, float u, float v) {
		vc.vertex(e, x, y, z)
			.color(0xFFFFFFFF)
			.texture(u, v)
			.overlay(OverlayTexture.DEFAULT_UV)
			.light(FULL_BRIGHT)
			.normal(e, 0f, 1f, 0f);
	}
}
