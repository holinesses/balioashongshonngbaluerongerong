package com.softcosmetics.client;

import com.softcosmetics.SoftCosmetics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;

public class HornsFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	private static final Identifier HORNS = Identifier.of(SoftCosmetics.MOD_ID, "textures/entity/frozen_horns.png");
	private static final Identifier FLAME = Identifier.of(SoftCosmetics.MOD_ID, "textures/entity/frozen_flame.png");

	/** Flame size in blocks. Change these to make the fire bigger or smaller. */
	private static final float FLAME_WIDTH = 0.36f;
	private static final float FLAME_HEIGHT = 0.9f;
	/** Where the flame starts above the neck pivot (head top = 0.5). */
	private static final float FLAME_BASE_UP = 0.48f;
	private static final int FULL_BRIGHT = 0xF000F0;

	public HornsFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
					   PlayerEntityRenderState state, float limbAngle, float limbDistance) {
		if (state.invisible) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null) return;
		Entity e = mc.world.getEntityById(state.id);
		if (!(e instanceof PlayerEntity p) || !p.getEquippedStack(EquipmentSlot.HEAD).isOf(SoftCosmetics.FROZEN_HORNS)) return;

		final float age = state.age;

		matrices.push();
		getContextModel().head.applyTransform(matrices); // follow the head's position, rotation and sneaking

		queue.submitCustom(matrices, RenderLayers.entityCutoutNoCull(HORNS),
			(entry, consumer) -> HornMesh.draw(entry, consumer, light));

		queue.submitCustom(matrices, RenderLayers.eyes(FLAME),
			(entry, consumer) -> drawFlame(entry, consumer, age));

		matrices.pop();
	}

	/** Three crossed flame sprites so it looks like a flame from every side. */
	private static void drawFlame(MatrixStack.Entry entry, VertexConsumer vc, float age) {
		float flicker = 1f + 0.07f * (float) Math.sin(age * 0.55f) + 0.04f * (float) Math.sin(age * 1.37f);
		float h = FLAME_HEIGHT * flicker;
		float w = FLAME_WIDTH * (1f + 0.03f * (float) Math.sin(age * 0.9f + 1f));
		float sway = 0.025f * (float) Math.sin(age * 0.4f);

		float yBottom = -FLAME_BASE_UP;     // model space is Y-down
		float yTop = -(FLAME_BASE_UP + h);

		for (int i = 0; i < 3; i++) {
			double a = Math.toRadians(i * 60.0);
			float dx = (float) Math.cos(a) * w / 2f;
			float dz = (float) Math.sin(a) * w / 2f;
			float sx = (float) Math.cos(a) * sway;
			float sz = (float) Math.sin(a) * sway;

			// front face, then back face (so it's visible whichever way culling goes)
			v(entry, vc, -dx, yBottom, -dz, 0, 1);
			v(entry, vc, dx, yBottom, dz, 1, 1);
			v(entry, vc, dx + sx, yTop, dz + sz, 1, 0);
			v(entry, vc, -dx + sx, yTop, -dz + sz, 0, 0);

			v(entry, vc, -dx + sx, yTop, -dz + sz, 0, 0);
			v(entry, vc, dx + sx, yTop, dz + sz, 1, 0);
			v(entry, vc, dx, yBottom, dz, 1, 1);
			v(entry, vc, -dx, yBottom, -dz, 0, 1);
		}
	}

	private static void v(MatrixStack.Entry e, VertexConsumer vc, float x, float y, float z, float u, float v) {
		vc.vertex(e, x, y, z)
			.color(0xFFFFFFFF)
			.texture(u, v)
			.overlay(OverlayTexture.DEFAULT_UV)
			.light(FULL_BRIGHT)
			.normal(e, 0f, 1f, 0f);
	}
}
