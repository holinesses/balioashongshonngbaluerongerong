package com.softcosmetics.client;

import com.softcosmetics.SoftCosmetics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;

public class HornsFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	private static final Identifier TEXTURE = Identifier.of(SoftCosmetics.MOD_ID, "textures/entity/frozen_horns.png");

	public HornsFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
					   PlayerEntityRenderState state, float limbAngle, float limbDistance) {
		if (state.invisible) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null) return;
		Entity e = mc.world.getEntityById(state.id);
		if (!(e instanceof PlayerEntity p) || !p.getEquippedStack(EquipmentSlot.HEAD).isOf(SoftCosmetics.FROZEN_HORNS)) return;

		matrices.push();
		ModelPart head = getContextModel().head;
		head.applyTransform(matrices); // follow the head's position, rotation and sneaking
		queue.submitCustom(matrices, RenderLayers.entityCutoutNoCull(TEXTURE),
			(entry, consumer) -> HornMesh.draw(entry, consumer, light));
		matrices.pop();
	}
}
