package com.softcosmetics.client;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Loads the Roblox OBJ once and draws it as triangles. */
public final class HornMesh {
	/** How many blocks one Roblox "stud" is. Make bigger/smaller horns by changing this. */
	public static final float SCALE_X = 0.48f;   // width (side to side)
	public static final float SCALE_Y = 0.38f;   // height
	public static final float SCALE_Z = 0.38f;   // thickness (front to back)
	/** The model has little thorny spike pieces wrapped around each horn. They look like extra small horns, so they are off by default. */
	public static final boolean SHOW_SPIKE_PIECES = false;
	/** How far above the neck pivot (in blocks) the bottom of the horns sits. Head top = 0.5. */
	public static final float BASE_UP = 0.40f;
	/** Horn tip positions in Roblox studs (x, y, z); used for the fire. */
	public static final float TIP_X = 1.14f, TIP_Y = 2.47f, TIP_Z = -0.03f;

	private static float[] data; // per corner: x y z u v nx ny nz
	private static int corners;

	private HornMesh() {}

	private static void load() {
		if (data != null) return;
		List<float[]> v = new ArrayList<>(), vt = new ArrayList<>(), vn = new ArrayList<>();
		List<int[]> faces = new ArrayList<>();
		try (InputStream in = HornMesh.class.getResourceAsStream(SHOW_SPIKE_PIECES
				? "/assets/softcosmetics/models/cosmetic/frozen_horns_full.obj"
				: "/assets/softcosmetics/models/cosmetic/frozen_horns.obj");
			 BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
			String line;
			while ((line = r.readLine()) != null) {
				String[] t = line.trim().split("\\s+");
				if (t.length < 3) continue;
				switch (t[0]) {
					case "v" -> v.add(new float[]{f(t[1]), f(t[2]), f(t[3])});
					case "vt" -> vt.add(new float[]{f(t[1]), f(t[2])});
					case "vn" -> vn.add(new float[]{f(t[1]), f(t[2]), f(t[3])});
					case "f" -> {
						for (int i = 1; i <= 3; i++) {
							String[] p = t[i].split("/");
							faces.add(new int[]{Integer.parseInt(p[0]) - 1, Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]) - 1});
						}
					}
					default -> {}
				}
			}
		} catch (Exception e) {
			throw new RuntimeException("Could not load frozen_horns.obj", e);
		}
		corners = faces.size();
		data = new float[corners * 8];
		for (int i = 0; i < corners; i++) {
			int[] c = faces.get(i);
			float[] p = v.get(c[0]), uv = vt.get(c[1]), n = vn.get(c[2]);
			int o = i * 8;
			// Roblox is Y-up; the player model space is Y-down, so flip Y.
			data[o] = p[0] * SCALE_X;
			data[o + 1] = -(BASE_UP + p[1] * SCALE_Y);
			data[o + 2] = p[2] * SCALE_Z;
			data[o + 3] = uv[0];
			data[o + 4] = 1f - uv[1];
			data[o + 5] = n[0];
			data[o + 6] = -n[1];
			data[o + 7] = n[2];
		}
	}

	private static float f(String s) { return Float.parseFloat(s); }

	public static void draw(MatrixStack.Entry entry, VertexConsumer vc, int light) {
		load();
		for (int i = 0; i < corners; i++) {
			vertex(entry, vc, i, light);
			if (i % 3 == 2) vertex(entry, vc, i, light); // layer draws quads: repeat last corner to make a triangle
		}
	}

	private static void vertex(MatrixStack.Entry e, VertexConsumer vc, int i, int light) {
		int o = i * 8;
		vc.vertex(e, data[o], data[o + 1], data[o + 2])
			.color(0xFFFFFFFF)
			.texture(data[o + 3], data[o + 4])
			.overlay(OverlayTexture.DEFAULT_UV)
			.light(light)
			.normal(e, data[o + 5], data[o + 6], data[o + 7]);
	}
}
