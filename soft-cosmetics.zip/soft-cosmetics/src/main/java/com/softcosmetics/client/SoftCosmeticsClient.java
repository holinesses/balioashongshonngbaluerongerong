package com.softcosmetics.client;

import com.softcosmetics.SoftCosmetics;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.random.Random;

public class SoftCosmeticsClient implements ClientModInitializer {
	/** Light blue (0xRRGGBB) for the fire glow. */
	private static final int FIRE_COLOR = 0x7FD8FF;

	@Override
	public void onInitializeClient() {
		LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
			if (renderer instanceof PlayerEntityRenderer playerRenderer) {
				helper.register(new HornsFeatureRenderer(playerRenderer));
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			ClientWorld world = mc.world;
			if (world == null) return;
			for (AbstractClientPlayerEntity p : world.getPlayers()) {
				if (p.isInvisible() || !p.getEquippedStack(EquipmentSlot.HEAD).isOf(SoftCosmetics.FROZEN_HORNS)) continue;
				// don't block your own view in first person
				if (p == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
				spawnFire(world, p);
			}
		});
	}

	private static void spawnFire(ClientWorld world, AbstractClientPlayerEntity p) {
		Random rand = world.random;
		double yaw = Math.toRadians(p.getHeadYaw());
		double leftX = Math.cos(yaw), leftZ = Math.sin(yaw);       // player's left
		double fwdX = -Math.sin(yaw), fwdZ = Math.cos(yaw);        // player's forward
		double neckY = p.getEyeY() - 0.22;                         // head pivot, roughly
		double k = 0.9375;                                          // player model scale

		for (int side = -1; side <= 1; side += 2) {
			double lx = side * HornMesh.TIP_X * HornMesh.SCALE * k;
			double lz = HornMesh.TIP_Z * HornMesh.SCALE * k;
			double up = (HornMesh.BASE_UP + HornMesh.TIP_Y * HornMesh.SCALE) * k;
			double x = p.getX() + leftX * lx + fwdX * lz + (rand.nextDouble() - 0.5) * 0.05;
			double y = neckY + up;
			double z = p.getZ() + leftZ * lx + fwdZ * lz + (rand.nextDouble() - 0.5) * 0.05;

			// blue flame (vanilla soul fire) + a light blue glow on top
			if (rand.nextInt(2) == 0) world.addParticleClient(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 0, 0.02, 0);
			world.addParticleClient(new DustParticleEffect(FIRE_COLOR, 0.8f), x, y, z,
				(rand.nextDouble() - 0.5) * 0.01, 0.03 + rand.nextDouble() * 0.02, (rand.nextDouble() - 0.5) * 0.01);
		}
	}
}
